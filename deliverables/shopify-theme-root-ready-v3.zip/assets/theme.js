"use strict";
(() => {
  // src/theme.ts
  var root = document.documentElement;
  root.classList.add("js-enabled");
  var qs = (selector, parent = document) => {
    return parent.querySelector(selector);
  };
  var qsa = (selector, parent = document) => {
    return Array.from(parent.querySelectorAll(selector));
  };
  var initHeaderBehavior = () => {
    const header = qs(".site-header");
    if (!header) {
      return;
    }
    const syncHeader = () => {
      header.classList.toggle("scrolled", window.scrollY > 12);
    };
    syncHeader();
    window.addEventListener("scroll", syncHeader, { passive: true });
  };
  var initMobileMenu = () => {
    const menuToggle = qs("[data-mobile-toggle]");
    const menuDrawer = qs("[data-mobile-drawer]");
    if (!menuToggle || !menuDrawer) {
      return;
    }
    const closeDrawer = () => {
      menuDrawer.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
    };
    const openDrawer = () => {
      menuDrawer.classList.add("open");
      menuToggle.setAttribute("aria-expanded", "true");
    };
    menuToggle.addEventListener("click", () => {
      const isOpen = menuDrawer.classList.contains("open");
      if (isOpen) {
        closeDrawer();
        return;
      }
      openDrawer();
    });
    qsa("a", menuDrawer).forEach((link) => {
      link.addEventListener("click", closeDrawer);
    });
    document.addEventListener("click", (event) => {
      const target = event.target;
      if (!target) {
        return;
      }
      if (!menuDrawer.contains(target) && !menuToggle.contains(target)) {
        closeDrawer();
      }
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        closeDrawer();
      }
    });
  };
  var initFAQ = () => {
    const faqItems = qsa(".faq-item");
    if (!faqItems.length) {
      return;
    }
    const syncIcon = (item) => {
      const icon = qs("[data-faq-icon]", item);
      if (icon) {
        icon.textContent = item.open ? "-" : "+";
      }
    };
    faqItems.forEach((item) => {
      syncIcon(item);
      item.addEventListener("toggle", () => {
        if (item.open) {
          faqItems.forEach((other) => {
            if (other !== item) {
              other.open = false;
              syncIcon(other);
            }
          });
        }
        syncIcon(item);
      });
    });
  };
  var initRevealEffects = () => {
    const targets = [
      ...qsa(".section-shell"),
      ...qsa(".cta-banner")
    ];
    if (!targets.length) {
      return;
    }
    targets.forEach((element) => {
      element.classList.add("reveal-section");
    });
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      targets.forEach((element) => {
        element.classList.add("in-view");
      });
      return;
    }
    if (!("IntersectionObserver" in window)) {
      targets.forEach((element) => {
        element.classList.add("in-view");
      });
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.15,
        rootMargin: "0px 0px -6% 0px"
      }
    );
    targets.forEach((target) => {
      observer.observe(target);
    });
  };
  var initFormExperience = () => {
    const forms = qsa('form[action*="/contact"], form[action*="/account/contact"]');
    forms.forEach((form) => {
      form.addEventListener("submit", () => {
        root.style.scrollBehavior = "smooth";
      });
    });
  };
  var bootstrap = () => {
    initHeaderBehavior();
    initMobileMenu();
    initFAQ();
    initRevealEffects();
    initFormExperience();
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrap);
  } else {
    bootstrap();
  }
})();
